# scipub 1.0.0

* Added a `NEWS.md` file to track changes to the package.

# scipub 1.2.0

* added new gg_grouplot function
* fixed issue in correltable

# scipub 1.1.0

* added new partial_correltable function
* fixed issue for FullTable1 arising from potential
  to be missing data for one group of a strata 
  variable, e.g. symptom scores available for only
  patients but not for a healthy group
* fixed cutempty behavior for correltable
* fixed output behavior for apastat

